from collections import deque

def bfs(graph, start, goal):
    # Create a queue for BFS
    queue = deque([[start]])
    # Set to keep track of visited nodes
    visited = set()

    # Loop until the queue is empty
    while queue:
        # Dequeue the first path from the queue
        path = queue.popleft()
        # Get the last node from the path
        node = path[-1]

        # If this node is the goal, return the path
        if node == goal:
            return path

        # If the node has not been visited yet
        if node not in visited:
            # Mark the node as visited
            visited.add(node)

            # Add new paths to the queue with all adjacent nodes
            for adjacent in graph.get(node, []):
                new_path = list(path)
                new_path.append(adjacent)
                queue.append(new_path)

    # If no path is found, return None
    return None

# Example graph represented as an adjacency list
graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F'],
    'D': [],
    'E': ['F'],
    'F': []
}

# Perform BFS to find the shortest path from 'A' to 'F'
start_node = 'A'
goal_node = 'F'
path = bfs(graph, start_node, goal_node)

if path:
    print("Shortest path:", path)
else:
    print("No path found")
