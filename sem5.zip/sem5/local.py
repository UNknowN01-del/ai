import random

def hill_climbing(func, start, step_size=0.1, max_iterations=1000):
    current_x = start  # Start point
    current_value = func(current_x)  # Evaluate the function at the starting point
    
    for _ in range(max_iterations):
        # Generate a neighbor by moving left and right from the current position
        left_x = current_x - step_size
        right_x = current_x + step_size
        
        # Evaluate the function at neighboring points
        left_value = func(left_x)
        right_value = func(right_x)
        
        # Check which neighbor is better
        if left_value > current_value:
            current_x, current_value = left_x, left_value
        elif right_value > current_value:
            current_x, current_value = right_x, right_value
        else:
            # If neither neighbor is better, we've reached a peak
            break
    
    return current_x, current_value

# Example function: f(x) = -(x^2) + 10
def example_function(x):
    return -(x**2) + 10

# Initial starting point
start_point = random.uniform(-10, 10)

# Perform hill climbing
solution_x, solution_value = hill_climbing(example_function, start_point)

print(f"Maximum value found at x = {solution_x:.2f}, f(x) = {solution_value:.2f}")
