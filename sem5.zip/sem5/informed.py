import heapq

def a_star(start, goal):
    queue = [(0, start, [start])]  # Initialize queue with start state and path
    visited = set([start])  # Keep track of visited states

    while queue:
        cost, current, path = heapq.heappop(queue)
        
        # Check if goal is reached
        if current == goal:
            return path

        # Get possible moves from the current state
        for move in get_moves(current):
            if move not in visited:
                visited.add(move)
                new_cost = cost + heuristic(move, goal)
                heapq.heappush(queue, (new_cost, move, path + [move]))

    return None  # No path found

def heuristic(state, goal):
    # Example heuristic: Manhattan distance for 8-puzzle
    return sum(abs((state.index(str(i)) // 3) - (goal.index(str(i)) // 3)) + 
               abs((state.index(str(i)) % 3) - (goal.index(str(i)) % 3)) 
               for i in range(1, 9))

def get_moves(state):
    # Generate possible moves for the 8-puzzle
    moves = []
    zero_index = state.index('0')
    row, col = divmod(zero_index, 3)

    # Directions for moving the blank tile (0): up, down, left, right
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    for dr, dc in directions:
        new_row, new_col = row + dr, col + dc
        if 0 <= new_row < 3 and 0 <= new_col < 3:
            new_index = new_row * 3 + new_col
            new_state = list(state)
            # Swap blank tile with the adjacent tile
            new_state[zero_index], new_state[new_index] = new_state[new_index], new_state[zero_index]
            moves.append(''.join(new_state))

    return moves

# Example start and goal state for 8-puzzle
start = "123405678"  # Example scrambled state
goal = "123456780"   # Goal state

path = a_star(start, goal)
if path:
    print("Solution path:", path)
else:
    print("No solution found")
